<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>toggle</title>

    <style>
        .toggle-buttons{
            min-width: 300px;
            display: flex;
            margin-left: 25%;
            margin-right: auto;
        }
        .toggle-buttons a{
            background-color: grey;
            text-decoration: none;
            color: white;
            padding: 10px 120px;
            font-size: 20px;
            margin-left: 5px;;
        }
        .toggle-div{
            max-width: 560px;
            margin-left: 25%;
            margin-right: auto; 
            background-color: gray;
        }

        .hide{
            display: none;
        }
    </style>

</head>
<body>

<div class="toggle-buttons">
    <a href="#" onclick="eat()">Eat</a>
    <a href="#" onclick="drink()">Drink</a>
</div>

<div id="eat" class="toggle-div">
        <h3>Bread Basket</h3>
        <p>Assortment of fresh baked fruit breads and muffins 5.50</p>
        <br>
        <h3>Honey Almond Granola with Fruits</h3>
        <p>Natural cereal of honey toasted oats, raisins, almonds and dates 7.00</p>
        <br>

</div>

<div id="drink" class="toggle-div hide">

    <h3>Coffee</h3>
    <p>Regular coffee 2.50</p>
    <br>
    <h3>Chocolato</h3>
    <p>Chocolate espresso with milk 4.50</p>
    <br>

</div>

<script>
function eat(){
    var drink = document.getElementById('drink');
    var eat = document.getElementById('eat');

    drink.classList.add("hide");
    eat.classList.remove('hide');
}

function drink(){
    var drink = document.getElementById('drink');
    var eat = document.getElementById('eat');

    eat.classList.add("hide");
    drink.classList.remove('hide');
}
</script>

</body>
</html>